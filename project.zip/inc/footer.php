            </div>
            </div>

            <footer class="main-footer">
                <div class="container">
                    <div class="main-footer__copyright">
                        <p><?= COPYRIGHT ?></p>

                        <p><?= COPYRIGHT_DESC ?></p>
                    </div>

                    <div class="main-footer__social social">

                        <a class="main-navigation__list-item-link" href="#">О проекте</a>

                    </div>
                    <div class="main-footer__social social">

                        <a class="main-navigation__list-item-link" href="#">Что-то еще</a>

                    </div>


                    <div class="main-footer__developed-by">
                        <a href="https://fixitgames.ru" target="_blank">
                            <img src="../img/company-grey.png" alt="FixIt Games" width="80" height="80">
                        </a>
                    </div>
                </div>
            </footer>


            </body>

            </html>