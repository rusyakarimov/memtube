 <script src="../js/bootstrap.bundle.min.js"></script>
 <!-- Footer-->
 <footer class="py-5 bg-dark">
     <div class="container">
         <p class="m-0 text-center text-white">
             <a href="/"><img src="../img/logo.png" alt="Логотип MEM-TUBE"></a>
         </p>
         <p class="m-0 text-center text-white">
             &copy; MEM-TUBE, 2022</p>
     </div>
 </footer>

 </body>

 </html>