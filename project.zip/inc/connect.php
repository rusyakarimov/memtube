<?php
$db = new db(DBHOST, DBUSER, DBPASSWORD, DBNAME) or die("ERROR");
